module.exports=[28225,(a,b,c)=>{}];

//# sourceMappingURL=955de_institute_ascension-app__next-internal_server_app_page_actions_92fbe270.js.map