module.exports=[66683,(a,b,c)=>{}];

//# sourceMappingURL=1b91c_ascension-app__next-internal_server_app__global-error_page_actions_30d828f0.js.map