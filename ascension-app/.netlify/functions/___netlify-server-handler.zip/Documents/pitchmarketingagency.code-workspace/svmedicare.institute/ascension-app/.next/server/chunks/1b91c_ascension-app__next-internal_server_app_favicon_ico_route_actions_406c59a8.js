module.exports=[52587,(e,o,d)=>{}];

//# sourceMappingURL=1b91c_ascension-app__next-internal_server_app_favicon_ico_route_actions_406c59a8.js.map