globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a0ac35a6782d9e64.js",
    "static/chunks/7beca575d61481a6.js",
    "static/chunks/e92e52b3b6efd9b7.js",
    "static/chunks/070ed390f01a598c.js",
    "static/chunks/turbopack-7d48593e7d267bb4.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];