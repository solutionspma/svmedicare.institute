module.exports=[9682,(a,b,c)=>{}];

//# sourceMappingURL=1b91c_ascension-app__next-internal_server_app_dashboard_page_actions_9a4229f8.js.map