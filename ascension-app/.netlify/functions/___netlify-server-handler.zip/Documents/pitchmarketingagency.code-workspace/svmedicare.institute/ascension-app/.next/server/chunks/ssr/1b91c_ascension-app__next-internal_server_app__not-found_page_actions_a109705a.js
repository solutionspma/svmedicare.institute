module.exports=[2960,(a,b,c)=>{}];

//# sourceMappingURL=1b91c_ascension-app__next-internal_server_app__not-found_page_actions_a109705a.js.map