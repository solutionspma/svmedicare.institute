module.exports=[39468,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},55686,a=>{"use strict";let b={src:a.i(39468).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=c7a7f_code-workspace_svmedicare_institute_ascension-app_src_app_467bac0f._.js.map